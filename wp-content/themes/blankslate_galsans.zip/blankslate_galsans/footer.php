
<footer>
<span>Created By <?php the_author(); ?> - <?php the_date('Y'); ?></span>
</footer>

<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"> -->
    <script src="http://localhost/wp/wp-content/uploads/custom-css-js/32.js"></script>
</script>

</body>

</html>